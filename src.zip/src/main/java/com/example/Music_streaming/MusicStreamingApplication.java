package com.example.Music_streaming;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusicStreamingApplication {

	public static void main(String[] args) {
		SpringApplication.run(MusicStreamingApplication.class, args);
	}

}
